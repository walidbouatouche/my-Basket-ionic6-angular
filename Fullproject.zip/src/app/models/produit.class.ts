
export class produit {
    id:number ;
    nom:string;
    prix:number;
    image_url?:string ;
    User_id:number ;
}