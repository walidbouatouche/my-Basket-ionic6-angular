
export class user {
    id?:number ;
    nom:string;
    password:string ;
}