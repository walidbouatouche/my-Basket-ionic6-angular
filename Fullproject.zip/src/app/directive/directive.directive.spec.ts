import { DirectiveDirective } from './directive.directive';

describe('DirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new DirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
